let unit = "Unit 6";
let title = "A Visit to a School";
var VOCABS = [
  { en: "campus", vi: "khuôn viên trường", pos: "n.", eg: "The campus is large and green." },
  { en: "principal", vi: "hiệu trưởng", pos: "n.", eg: "The principal welcomes new students." },
  { en: "subject", vi: "môn học", pos: "n.", eg: "Math is my favorite subject." },
  { en: "timetable", vi: "thời khóa biểu", pos: "n.", eg: "Check the timetable on the board." },
  { en: "laboratory", vi: "phòng thí nghiệm", pos: "n.", eg: "We do experiments in the laboratory." },
  { en: "library", vi: "thư viện", pos: "n.", eg: "The library has many books." },
  { en: "canteen", vi: "căng tin", pos: "n.", eg: "We have lunch in the canteen." },
  { en: "playground", vi: "sân chơi", pos: "n.", eg: "Students play in the playground." },
  { en: "auditorium", vi: "hội trường", pos: "n.", eg: "The ceremony is in the auditorium." },
  { en: "classroom", vi: "phòng học", pos: "n.", eg: "Our classroom is on the second floor." },
  { en: "uniform", vi: "đồng phục", pos: "n.", eg: "We wear school uniforms." },
  { en: "boarding school", vi: "trường nội trú", pos: "n.", eg: "He studies at a boarding school." },
  { en: "attendance", vi: "sự điểm danh, tham dự", pos: "n.", eg: "Attendance is checked every morning." },
  { en: "discipline", vi: "kỷ luật", pos: "n.", eg: "The school has strict discipline." },
  { en: "assembly", vi: "chào cờ, họp toàn trường", pos: "n.", eg: "We have assembly on Monday." },
  { en: "club", vi: "câu lạc bộ", pos: "n.", eg: "She joins the English club." },
  { en: "dormitory", vi: "kí túc xá", pos: "n.", eg: "The dormitory is near the gym." },
  { en: "experiment", vi: "thí nghiệm", pos: "n.", eg: "We did a physics experiment." },
  { en: "semester", vi: "học kì", pos: "n.", eg: "The first semester ends in December." },
  { en: "field trip", vi: "chuyến đi thực tế", pos: "n.", eg: "We will go on a field trip next week." }
];