let unit = "Unit 2";
let title = "Healthy Living";
var VOCABS = [
  { en: "healthy", vi: "lành mạnh, khỏe mạnh", pos: "adj.", eg: "A healthy diet is important." },
  { en: "balanced diet", vi: "chế độ ăn cân bằng", pos: "n.", eg: "You should have a balanced diet." },
  { en: "junk food", vi: "đồ ăn vặt không tốt", pos: "n.", eg: "Cut down on junk food." },
  { en: "vegetable", vi: "rau củ", pos: "n.", eg: "Eat more fresh vegetables." },
  { en: "fruit", vi: "trái cây", pos: "n.", eg: "Fruit provides vitamins." },
  { en: "vitamin", vi: "vitamin", pos: "n.", eg: "Vitamin C is good for your skin." },
  { en: "protein", vi: "chất đạm", pos: "n.", eg: "Beans are rich in protein." },
  { en: "fat", vi: "chất béo", pos: "n.", eg: "Limit saturated fat." },
  { en: "calorie", vi: "calo", pos: "n.", eg: "This drink has too many calories." },
  { en: "exercise", vi: "tập thể dục", pos: "v./n.", eg: "We should exercise every day." },
  { en: "sleep", vi: "giấc ngủ; ngủ", pos: "n./v.", eg: "Enough sleep helps you grow." },
  { en: "sunburn", vi: "cháy nắng", pos: "n.", eg: "Wear a hat to avoid sunburn." },
  { en: "allergy", vi: "dị ứng", pos: "n.", eg: "He has a peanut allergy." },
  { en: "disease", vi: "bệnh tật", pos: "n.", eg: "Smoking can cause heart disease." },
  { en: "hydrate", vi: "cung cấp nước", pos: "v.", eg: "Remember to hydrate during exercise." },
  { en: "sneeze", vi: "hắt hơi", pos: "v.", eg: "She sneezes because of the dust." },
  { en: "overweight", vi: "thừa cân", pos: "adj.", eg: "Being overweight is not healthy." },
  { en: "medical check-up", vi: "khám sức khỏe", pos: "n.", eg: "Have a medical check-up yearly." },
  { en: "first aid", vi: "sơ cứu", pos: "n.", eg: "He learned first aid at school." },
  { en: "avoid", vi: "tránh", pos: "v.", eg: "Avoid eating too much sugar." }
];