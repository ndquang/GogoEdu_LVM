let unit = "Unit 4";
let title = "Music and Arts";
var VOCABS = [
  { en: "instrument", vi: "nhạc cụ", pos: "n.", eg: "She plays a musical instrument." },
  { en: "musician", vi: "nhạc sĩ", pos: "n.", eg: "He wants to be a musician." },
  { en: "singer", vi: "ca sĩ", pos: "n.", eg: "The singer has a beautiful voice." },
  { en: "composer", vi: "nhà soạn nhạc", pos: "n.", eg: "Beethoven is a great composer." },
  { en: "melody", vi: "giai điệu", pos: "n.", eg: "I love the melody of this song." },
  { en: "rhythm", vi: "nhịp điệu", pos: "n.", eg: "Clap to the rhythm." },
  { en: "lyrics", vi: "lời bài hát", pos: "n.", eg: "The lyrics are meaningful." },
  { en: "concert", vi: "buổi hòa nhạc", pos: "n.", eg: "They went to a concert last night." },
  { en: "stage", vi: "sân khấu", pos: "n.", eg: "The band is on the stage." },
  { en: "painting", vi: "bức tranh; hội họa", pos: "n.", eg: "That painting is famous." },
  { en: "sculpture", vi: "điêu khắc; bức tượng", pos: "n.", eg: "The museum has modern sculptures." },
  { en: "gallery", vi: "phòng trưng bày", pos: "n.", eg: "We visited an art gallery." },
  { en: "perform", vi: "biểu diễn", pos: "v.", eg: "The students perform a play." },
  { en: "voice", vi: "giọng hát", pos: "n.", eg: "Her voice is powerful." },
  { en: "classical music", vi: "nhạc cổ điển", pos: "n.", eg: "He enjoys classical music." },
  { en: "pop music", vi: "nhạc pop", pos: "n.", eg: "Pop music is popular among teens." },
  { en: "brush", vi: "cọ vẽ", pos: "n.", eg: "She needs a new paint brush." },
  { en: "canvas", vi: "vải vẽ", pos: "n.", eg: "He paints on a big canvas." },
  { en: "talent", vi: "tài năng", pos: "n.", eg: "She shows her talent at the show." },
  { en: "applause", vi: "tiếng vỗ tay", pos: "n.", eg: "The audience gives loud applause." }
];