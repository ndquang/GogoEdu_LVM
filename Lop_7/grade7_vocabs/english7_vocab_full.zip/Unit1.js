let unit = "Unit 1";
let title = "Hobbies";
var VOCABS = [
  { en: "hobby", vi: "sở thích", pos: "n.", eg: "My hobby is reading books." },
  { en: "collect", vi: "sưu tầm", pos: "v.", eg: "She likes to collect stamps." },
  { en: "collector", vi: "người sưu tầm", pos: "n.", eg: "He is a famous coin collector." },
  { en: "collection", vi: "bộ sưu tập", pos: "n.", eg: "Her shell collection is impressive." },
  { en: "play chess", vi: "chơi cờ vua", pos: "v. phr.", eg: "We often play chess after dinner." },
  { en: "do gardening", vi: "làm vườn", pos: "v. phr.", eg: "My grandpa does gardening on weekends." },
  { en: "bird-watching", vi: "ngắm chim", pos: "n.", eg: "Bird-watching is a relaxing hobby." },
  { en: "go fishing", vi: "đi câu cá", pos: "v. phr.", eg: "They go fishing every Sunday." },
  { en: "yoga", vi: "yoga", pos: "n.", eg: "She practices yoga every evening." },
  { en: "model making", vi: "làm mô hình", pos: "n.", eg: "Model making requires patience." },
  { en: "take photos", vi: "chụp ảnh", pos: "v. phr.", eg: "I like to take photos of nature." },
  { en: "cycling", vi: "đạp xe", pos: "n.", eg: "Cycling keeps me fit." },
  { en: "camping", vi: "cắm trại", pos: "n.", eg: "Camping is popular in summer." },
  { en: "music", vi: "âm nhạc", pos: "n.", eg: "Listening to music helps me relax." },
  { en: "dance", vi: "nhảy múa", pos: "v.", eg: "She can dance very well." },
  { en: "stamp", vi: "tem", pos: "n.", eg: "This stamp is very rare." },
  { en: "knitting", vi: "đan len", pos: "n.", eg: "Knitting is my grandmother's hobby." },
  { en: "draw", vi: "vẽ", pos: "v.", eg: "He can draw animals." },
  { en: "creative", vi: "sáng tạo", pos: "adj.", eg: "Hobbies can make you more creative." },
  { en: "relaxing", vi: "thư giãn", pos: "adj.", eg: "Reading is relaxing." }
];