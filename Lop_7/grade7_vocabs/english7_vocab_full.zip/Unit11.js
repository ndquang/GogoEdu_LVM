let unit = "Unit 11";
let title = "Travelling in the Future";
var VOCABS = [
  { en: "vehicle", vi: "phương tiện", pos: "n.", eg: "Future vehicles may fly." },
  { en: "teleport", vi: "dịch chuyển tức thời", pos: "v.", eg: "People dream to teleport someday." },
  { en: "driverless", vi: "không người lái", pos: "adj.", eg: "Driverless cars are being tested." },
  { en: "hover", vi: "lơ lửng", pos: "v.", eg: "The car can hover above ground." },
  { en: "jet pack", vi: "thiết bị bay cá nhân", pos: "n.", eg: "He flew with a jet pack." },
  { en: "hyperloop", vi: "siêu ống vận tải", pos: "n.", eg: "Hyperloop could be very fast." },
  { en: "space tourism", vi: "du lịch vũ trụ", pos: "n.", eg: "Space tourism is expensive now." },
  { en: "ticket", vi: "vé", pos: "n.", eg: "We booked tickets online." },
  { en: "timetable", vi: "lịch trình", pos: "n.", eg: "Check the timetable before you go." },
  { en: "route", vi: "tuyến đường", pos: "n.", eg: "This is the fastest route." },
  { en: "luggage", vi: "hành lý", pos: "n.", eg: "Pack your luggage light." },
  { en: "passport", vi: "hộ chiếu", pos: "n.", eg: "Don't forget your passport." },
  { en: "destination", vi: "điểm đến", pos: "n.", eg: "Our destination is Da Nang." },
  { en: "reservation", vi: "đặt chỗ", pos: "n.", eg: "Make a reservation early." },
  { en: "accommodation", vi: "chỗ ở", pos: "n.", eg: "We found cheap accommodation." },
  { en: "itinerary", vi: "kế hoạch hành trình", pos: "n.", eg: "The tour guide sent the itinerary." },
  { en: "delay", vi: "trì hoãn", pos: "n./v.", eg: "The flight was delayed." },
  { en: "upgrade", vi: "nâng hạng, nâng cấp", pos: "v./n.", eg: "We got a seat upgrade." },
  { en: "travel insurance", vi: "bảo hiểm du lịch", pos: "n.", eg: "Buy travel insurance for safety." },
  { en: "souvenir", vi: "quà lưu niệm", pos: "n.", eg: "I bought a small souvenir." }
];