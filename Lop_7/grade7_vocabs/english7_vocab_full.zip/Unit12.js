let unit = "Unit 12";
let title = "English-Speaking Countries";
var VOCABS = [
  { en: "country", vi: "quốc gia", pos: "n.", eg: "There are many English-speaking countries." },
  { en: "culture", vi: "văn hóa", pos: "n.", eg: "We learn about culture and customs." },
  { en: "tradition", vi: "truyền thống", pos: "n.", eg: "Each country has its traditions." },
  { en: "custom", vi: "phong tục", pos: "n.", eg: "It's a local custom to shake hands." },
  { en: "landmark", vi: "địa danh nổi tiếng", pos: "n.", eg: "Big Ben is a famous landmark." },
  { en: "capital", vi: "thủ đô", pos: "n.", eg: "Ottawa is the capital of Canada." },
  { en: "population", vi: "dân số", pos: "n.", eg: "The population is growing." },
  { en: "official language", vi: "ngôn ngữ chính thức", pos: "n.", eg: "English is an official language." },
  { en: "currency", vi: "đơn vị tiền tệ", pos: "n.", eg: "The currency in the UK is the pound." },
  { en: "symbol", vi: "biểu tượng", pos: "n.", eg: "The maple leaf is a symbol of Canada." },
  { en: "flag", vi: "quốc kỳ", pos: "n.", eg: "The flag has a Union Jack." },
  { en: "accent", vi: "giọng phát âm", pos: "n.", eg: "She speaks with a British accent." },
  { en: "native speaker", vi: "người bản ngữ", pos: "n.", eg: "We talked to native speakers." },
  { en: "continent", vi: "châu lục", pos: "n.", eg: "Australia is a continent and a country." },
  { en: "colony", vi: "thuộc địa", pos: "n.", eg: "It used to be a colony." },
  { en: "heritage", vi: "di sản", pos: "n.", eg: "We visit a world heritage site." },
  { en: "multicultural", vi: "đa văn hóa", pos: "adj.", eg: "Canada is multicultural." },
  { en: "festival", vi: "lễ hội", pos: "n.", eg: "They hold a summer festival." },
  { en: "geography", vi: "địa lý", pos: "n.", eg: "Geography teaches about countries." },
  { en: "education", vi: "giáo dục", pos: "n.", eg: "Education is important everywhere." }
];