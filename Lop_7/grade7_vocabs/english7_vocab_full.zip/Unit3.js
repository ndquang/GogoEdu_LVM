let unit = "Unit 3";
let title = "Community Service";
var VOCABS = [
  { en: "community", vi: "cộng đồng", pos: "n.", eg: "We work for the local community." },
  { en: "volunteer", vi: "tình nguyện viên; tình nguyện", pos: "n./v.", eg: "She volunteers at the shelter." },
  { en: "donate", vi: "quyên góp, hiến tặng", pos: "v.", eg: "They donate books to poor children." },
  { en: "charity", vi: "từ thiện", pos: "n.", eg: "The charity helps homeless people." },
  { en: "blood donation", vi: "hiến máu", pos: "n.", eg: "Our class joins a blood donation." },
  { en: "clean-up", vi: "dọn vệ sinh", pos: "n.", eg: "We join a beach clean-up." },
  { en: "elderly", vi: "người cao tuổi", pos: "n.", eg: "Students visit the elderly on weekends." },
  { en: "disabled", vi: "khuyết tật", pos: "adj.", eg: "A ramp helps disabled people." },
  { en: "raise funds", vi: "gây quỹ", pos: "v. phr.", eg: "They sell cookies to raise funds." },
  { en: "recycle", vi: "tái chế", pos: "v.", eg: "Please recycle paper and bottles." },
  { en: "environment", vi: "môi trường", pos: "n.", eg: "We protect the environment." },
  { en: "soup kitchen", vi: "bếp ăn từ thiện", pos: "n.", eg: "He serves meals at a soup kitchen." },
  { en: "homeless", vi: "vô gia cư", pos: "adj./n.", eg: "They help the homeless." },
  { en: "orphanage", vi: "trại mồ côi", pos: "n.", eg: "We visit an orphanage monthly." },
  { en: "benefit", vi: "lợi ích", pos: "n.", eg: "Volunteering brings many benefits." },
  { en: "encourage", vi: "khuyến khích", pos: "v.", eg: "Teachers encourage students to help." },
  { en: "take part in", vi: "tham gia", pos: "v. phr.", eg: "We take part in a charity walk." },
  { en: "organize", vi: "tổ chức", pos: "v.", eg: "They organize a book fair." },
  { en: "campaign", vi: "chiến dịch", pos: "n.", eg: "The school runs a recycling campaign." },
  { en: "support", vi: "hỗ trợ", pos: "v./n.", eg: "We support poor families." }
];