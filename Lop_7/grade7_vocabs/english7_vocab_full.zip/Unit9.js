let unit = "Unit 9";
let title = "Festivals Around the World";
var VOCABS = [
  { en: "festival", vi: "lễ hội", pos: "n.", eg: "There are many festivals in spring." },
  { en: "celebrate", vi: "ăn mừng, kỷ niệm", pos: "v.", eg: "People celebrate the new year." },
  { en: "parade", vi: "diễu hành", pos: "n.", eg: "The parade is colorful." },
  { en: "firework", vi: "pháo hoa", pos: "n.", eg: "Fireworks light up the sky." },
  { en: "costume", vi: "trang phục", pos: "n.", eg: "They wear traditional costumes." },
  { en: "tradition", vi: "truyền thống", pos: "n.", eg: "The festival keeps old traditions." },
  { en: "ritual", vi: "nghi lễ", pos: "n.", eg: "They perform a ritual at the temple." },
  { en: "lantern", vi: "đèn lồng", pos: "n.", eg: "Lanterns are hung along the street." },
  { en: "mask", vi: "mặt nạ", pos: "n.", eg: "Children wear masks at festivals." },
  { en: "harvest", vi: "mùa gặt; thu hoạch", pos: "n./v.", eg: "We celebrate the harvest." },
  { en: "float", vi: "xe hoa, thuyền trang trí", pos: "n.", eg: "The float moves slowly along." },
  { en: "music performance", vi: "biểu diễn âm nhạc", pos: "n.", eg: "A music performance opens the festival." },
  { en: "offering", vi: "đồ cúng, lễ vật", pos: "n.", eg: "People bring offerings to the altar." },
  { en: "crowd", vi: "đám đông", pos: "n.", eg: "The crowd cheers loudly." },
  { en: "atmosphere", vi: "không khí", pos: "n.", eg: "The atmosphere is joyful." },
  { en: "traditionally", vi: "một cách truyền thống", pos: "adv.", eg: "People traditionally visit relatives." },
  { en: "organizer", vi: "ban tổ chức, người tổ chức", pos: "n.", eg: "Organizers plan the events." },
  { en: "poster", vi: "áp phích", pos: "n.", eg: "Posters advertise the festival." },
  { en: "booth", vi: "gian hàng", pos: "n.", eg: "We tried food at many booths." },
  { en: "parade route", vi: "tuyến đường diễu hành", pos: "n.", eg: "They stand along the parade route." }
];