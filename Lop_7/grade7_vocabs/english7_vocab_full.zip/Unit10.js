let unit = "Unit 10";
let title = "Energy Sources";
var VOCABS = [
  { en: "energy", vi: "năng lượng", pos: "n.", eg: "We need clean energy." },
  { en: "renewable", vi: "tái tạo", pos: "adj.", eg: "Wind is a renewable source." },
  { en: "non-renewable", vi: "không tái tạo", pos: "adj.", eg: "Coal is non-renewable." },
  { en: "fossil fuel", vi: "nhiên liệu hóa thạch", pos: "n.", eg: "Fossil fuels cause pollution." },
  { en: "solar power", vi: "năng lượng mặt trời", pos: "n.", eg: "Solar power is popular now." },
  { en: "wind turbine", vi: "tuabin gió", pos: "n.", eg: "A wind turbine generates electricity." },
  { en: "hydropower", vi: "thủy điện", pos: "n.", eg: "The dam produces hydropower." },
  { en: "biomass", vi: "sinh khối", pos: "n.", eg: "Biomass can be used for fuel." },
  { en: "geothermal", vi: "địa nhiệt", pos: "adj.", eg: "Geothermal energy comes from the earth." },
  { en: "electricity", vi: "điện", pos: "n.", eg: "We must save electricity." },
  { en: "consumption", vi: "sự tiêu thụ", pos: "n.", eg: "Energy consumption is rising." },
  { en: "save energy", vi: "tiết kiệm năng lượng", pos: "v. phr.", eg: "Turn off lights to save energy." },
  { en: "efficient", vi: "hiệu quả, tiết kiệm", pos: "adj.", eg: "LED bulbs are energy-efficient." },
  { en: "pollution", vi: "ô nhiễm", pos: "n.", eg: "Less pollution means cleaner air." },
  { en: "greenhouse gas", vi: "khí nhà kính", pos: "n.", eg: "CO2 is a greenhouse gas." },
  { en: "power plant", vi: "nhà máy điện", pos: "n.", eg: "A new power plant was built." },
  { en: "battery", vi: "pin", pos: "n.", eg: "Batteries store energy." },
  { en: "grid", vi: "lưới điện", pos: "n.", eg: "Solar homes can connect to the grid." },
  { en: "generate", vi: "tạo ra, phát điện", pos: "v.", eg: "Turbines generate electricity." },
  { en: "install", vi: "lắp đặt", pos: "v.", eg: "They install solar panels on the roof." }
];