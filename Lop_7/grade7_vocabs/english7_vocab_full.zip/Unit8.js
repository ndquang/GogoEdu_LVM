let unit = "Unit 8";
let title = "Films";
var VOCABS = [
  { en: "film", vi: "phim", pos: "n.", eg: "We watched a new film." },
  { en: "actor", vi: "diễn viên nam", pos: "n.", eg: "The actor is very famous." },
  { en: "actress", vi: "diễn viên nữ", pos: "n.", eg: "She is a talented actress." },
  { en: "director", vi: "đạo diễn", pos: "n.", eg: "The director won an award." },
  { en: "screenplay", vi: "kịch bản phim", pos: "n.", eg: "The screenplay is well written." },
  { en: "scene", vi: "cảnh phim", pos: "n.", eg: "This scene is so funny." },
  { en: "special effects", vi: "hiệu ứng đặc biệt", pos: "n.", eg: "The special effects look real." },
  { en: "comedy", vi: "hài kịch", pos: "n.", eg: "This comedy made us laugh." },
  { en: "horror", vi: "kinh dị", pos: "n.", eg: "I don't like horror films." },
  { en: "science fiction", vi: "khoa học viễn tưởng", pos: "n.", eg: "He loves science fiction movies." },
  { en: "romance", vi: "lãng mạn", pos: "n.", eg: "They enjoy romance films." },
  { en: "documentary", vi: "phim tài liệu", pos: "n.", eg: "The documentary is educational." },
  { en: "animation", vi: "hoạt hình", pos: "n.", eg: "We watched an animation." },
  { en: "actor's performance", vi: "màn trình diễn của diễn viên", pos: "n.", eg: "His performance is brilliant." },
  { en: "soundtrack", vi: "nhạc phim", pos: "n.", eg: "The soundtrack is beautiful." },
  { en: "subtitle", vi: "phụ đề", pos: "n.", eg: "Turn on the subtitles." },
  { en: "plot", vi: "cốt truyện", pos: "n.", eg: "The plot is exciting." },
  { en: "character", vi: "nhân vật", pos: "n.", eg: "My favorite character is the hero." },
  { en: "review", vi: "bài đánh giá", pos: "n.", eg: "I read a review before watching." },
  { en: "premiere", vi: "buổi công chiếu", pos: "n.", eg: "The premiere is next Friday." }
];