let unit = "Unit 5";
let title = "Food and Drink";
var VOCABS = [
  { en: "ingredient", vi: "nguyên liệu", pos: "n.", eg: "We need fresh ingredients." },
  { en: "recipe", vi: "công thức nấu ăn", pos: "n.", eg: "Can you share the recipe?" },
  { en: "spicy", vi: "cay", pos: "adj.", eg: "This soup is too spicy." },
  { en: "sweet", vi: "ngọt", pos: "adj.", eg: "Mangoes are sweet." },
  { en: "sour", vi: "chua", pos: "adj.", eg: "Lemons taste sour." },
  { en: "salty", vi: "mặn", pos: "adj.", eg: "The soup is a bit salty." },
  { en: "bitter", vi: "đắng", pos: "adj.", eg: "This medicine tastes bitter." },
  { en: "steam", vi: "hấp", pos: "v.", eg: "We steam the fish." },
  { en: "boil", vi: "luộc, đun sôi", pos: "v.", eg: "Boil the eggs for 8 minutes." },
  { en: "fry", vi: "rán, chiên", pos: "v.", eg: "Don't fry the food too long." },
  { en: "grill", vi: "nướng (vỉ)", pos: "v.", eg: "They grill the meat outdoors." },
  { en: "bake", vi: "nướng (lò)", pos: "v.", eg: "Bake the cake at 180°C." },
  { en: "serve", vi: "phục vụ", pos: "v.", eg: "Serve the dish hot." },
  { en: "diet", vi: "chế độ ăn", pos: "n.", eg: "He is on a low-salt diet." },
  { en: "portion", vi: "khẩu phần", pos: "n.", eg: "Eat smaller portions." },
  { en: "beverage", vi: "đồ uống", pos: "n.", eg: "Water is the best beverage." },
  { en: "cuisine", vi: "ẩm thực", pos: "n.", eg: "Vietnamese cuisine is delicious." },
  { en: "nutritious", vi: "bổ dưỡng", pos: "adj.", eg: "Soup with vegetables is nutritious." },
  { en: "taste", vi: "hương vị; nếm", pos: "n./v.", eg: "Taste the sauce before serving." },
  { en: "chop", vi: "băm, thái", pos: "v.", eg: "Chop the onions finely." }
];