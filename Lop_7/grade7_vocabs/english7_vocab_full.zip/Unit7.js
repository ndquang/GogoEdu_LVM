let unit = "Unit 7";
let title = "Traffic";
var VOCABS = [
  { en: "traffic", vi: "giao thông", pos: "n.", eg: "Traffic is heavy in the morning." },
  { en: "vehicle", vi: "phương tiện", pos: "n.", eg: "Bicycles are popular vehicles." },
  { en: "helmet", vi: "mũ bảo hiểm", pos: "n.", eg: "Always wear a helmet on a motorbike." },
  { en: "seat belt", vi: "dây an toàn", pos: "n.", eg: "Fasten your seat belt." },
  { en: "pedestrian", vi: "người đi bộ", pos: "n.", eg: "Pedestrians must use the pavement." },
  { en: "pavement", vi: "vỉa hè", pos: "n.", eg: "Don’t ride on the pavement." },
  { en: "crosswalk", vi: "vạch qua đường", pos: "n.", eg: "Use the crosswalk to cross." },
  { en: "traffic light", vi: "đèn giao thông", pos: "n.", eg: "Wait for the green traffic light." },
  { en: "speed limit", vi: "giới hạn tốc độ", pos: "n.", eg: "Follow the speed limit." },
  { en: "intersection", vi: "ngã tư, giao lộ", pos: "n.", eg: "Turn left at the intersection." },
  { en: "rush hour", vi: "giờ cao điểm", pos: "n.", eg: "Buses are crowded at rush hour." },
  { en: "lane", vi: "làn đường", pos: "n.", eg: "Keep in your lane." },
  { en: "overtake", vi: "vượt", pos: "v.", eg: "Don’t overtake on a bend." },
  { en: "fine", vi: "phạt tiền", pos: "n./v.", eg: "He paid a fine for parking wrong." },
  { en: "public transport", vi: "phương tiện công cộng", pos: "n.", eg: "We use public transport to save money." },
  { en: "traffic jam", vi: "tắc đường", pos: "n.", eg: "We were stuck in a traffic jam." },
  { en: "engine", vi: "động cơ", pos: "n.", eg: "The car engine is very loud." },
  { en: "horn", vi: "còi xe", pos: "n.", eg: "He pressed the horn twice." },
  { en: "park", vi: "đỗ xe", pos: "v.", eg: "Don’t park here." },
  { en: "accident", vi: "tai nạn", pos: "n.", eg: "Be careful to avoid accidents." }
];